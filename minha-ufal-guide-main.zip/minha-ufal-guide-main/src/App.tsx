import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import RU from "./pages/RU.tsx";
import Adicionar from "./pages/Adicionar.tsx";
import Extrato from "./pages/Extrato.tsx";
import Cardapio from "./pages/Cardapio.tsx";
import Fale from "./pages/Fale.tsx";
import Dashboard from "./pages/Dashboard.tsx";
import Fila from "./pages/Fila.tsx";
import Cartao from "./pages/Cartao.tsx";
import Instagram from "./pages/Instagram.tsx";
import Carteirinha from "./pages/Carteirinha.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/ru" element={<RU />} />
          <Route path="/adicionar" element={<Adicionar />} />
          <Route path="/extrato" element={<Extrato />} />
          <Route path="/cardapio" element={<Cardapio />} />
          <Route path="/fale" element={<Fale />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/fila" element={<Fila />} />
          <Route path="/cartao" element={<Cartao />} />
          <Route path="/instagram" element={<Instagram />} />
          <Route path="/carteirinha" element={<Carteirinha />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
