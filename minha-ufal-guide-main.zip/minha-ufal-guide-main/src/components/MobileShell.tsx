import { ReactNode } from "react";
import { Home, Wallet, Utensils, MessageCircle, Hand } from "lucide-react";
import { useLocation, useNavigate } from "react-router-dom";

type Props = {
  children: ReactNode;
  /** quando true, esconde o frame do telefone e ocupa a tela toda (não usado por padrão) */
  fullBleed?: boolean;
};

const tabs = [
  { to: "/", label: "Início", Icon: Home },
  { to: "/extrato", label: "Extrato", Icon: Wallet },
  { to: "/ru", label: "RU", Icon: Hand, center: true },
  { to: "/cardapio", label: "Cardápio", Icon: Utensils },
  { to: "/fale", label: "Fale", Icon: MessageCircle },
];

export default function MobileShell({ children }: Props) {
  const location = useLocation();
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-100 via-slate-50 to-blue-50 flex items-center justify-center p-0 md:p-6">
      {/* Phone frame on desktop */}
      <div className="w-full md:w-[420px] md:h-[860px] md:rounded-[2.75rem] md:border-8 md:border-slate-900 md:shadow-floating bg-background overflow-hidden relative flex flex-col">
        {/* notch */}
        <div className="hidden md:block absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-900 rounded-b-2xl z-50" />

        {/* status bar (mobile-style) */}
        <div className="hidden md:flex absolute top-2 left-0 right-0 px-8 justify-between text-[11px] text-white font-medium z-40 pointer-events-none">
          <span>9:06</span>
          <span>•••</span>
        </div>

        <main className="flex-1 overflow-y-auto pb-28 scroll-smooth">
          {children}
        </main>

        {/* Bottom nav */}
        <nav className="absolute bottom-0 left-0 right-0 bg-card/95 backdrop-blur-lg border-t border-border px-2 pt-2 pb-3 z-30">
          <div className="flex items-end justify-around relative">
            {tabs.map(({ to, label, Icon, center }) => {
              const active = location.pathname === to;
              if (center) {
                return (
                  <button
                    key={to}
                    onClick={() => navigate(to)}
                    className="relative -mt-8 flex flex-col items-center"
                    aria-label="Restaurante Universitário"
                  >
                    <div className="w-16 h-16 rounded-full bg-gradient-primary shadow-floating flex flex-col items-center justify-center text-primary-foreground transition-spring hover:scale-105">
                      <span className="font-black text-lg leading-none">RU</span>
                      <span className="text-[7px] uppercase tracking-wider opacity-90 mt-0.5">
                        Restaurante
                      </span>
                    </div>
                  </button>
                );
              }
              return (
                <button
                  key={to}
                  onClick={() => navigate(to)}
                  className={`flex flex-col items-center gap-1 px-3 py-1 rounded-lg transition-smooth ${
                    active ? "text-primary" : "text-muted-foreground"
                  }`}
                >
                  <Icon size={20} strokeWidth={active ? 2.4 : 1.8} />
                  <span className={`text-[10px] ${active ? "font-semibold" : ""}`}>{label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      </div>
    </div>
  );
}
