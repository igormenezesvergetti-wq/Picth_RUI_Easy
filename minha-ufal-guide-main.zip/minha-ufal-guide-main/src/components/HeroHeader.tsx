import { ChevronLeft, Info, Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useApp } from "@/lib/mockData";

type Props = {
  title?: string;
  subtitle?: string;
  showBack?: boolean;
  showLogo?: boolean;
  compact?: boolean;
};

export default function HeroHeader({ title, subtitle, showBack, showLogo, compact }: Props) {
  const navigate = useNavigate();
  const { user, notifications } = useApp();

  return (
    <div
      className={`relative bg-gradient-hero hero-pattern text-primary-foreground px-5 ${
        compact ? "pt-10 pb-6" : "pt-10 pb-14"
      } rounded-b-[2rem] overflow-hidden`}
    >
      <div className="flex items-center justify-between relative z-10">
        {showBack ? (
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 -ml-2 rounded-full hover:bg-white/10 flex items-center justify-center transition-smooth"
            aria-label="Voltar"
          >
            <ChevronLeft size={26} strokeWidth={2.2} />
          </button>
        ) : (
          <div className="w-9" />
        )}

        <button className="w-9 h-9 rounded-full hover:bg-white/10 flex items-center justify-center transition-smooth">
          <Info size={20} />
        </button>
      </div>

      <div className="flex items-end justify-between mt-3 relative z-10">
        {showLogo ? (
          <div className="flex flex-col">
            <div className="text-3xl font-black tracking-tight italic">minha</div>
            <div className="text-[10px] tracking-[0.3em] font-semibold opacity-90 -mt-1">
              UFAL
            </div>
          </div>
        ) : (
          <div>
            {title && <h1 className="text-2xl font-bold">{title}</h1>}
            {subtitle && <p className="text-sm opacity-90 mt-1">{subtitle}</p>}
          </div>
        )}

        <div className="flex items-center gap-3">
          <span className="font-semibold">{user.name}</span>
          <div className="w-11 h-11 rounded-full bg-white/20 border-2 border-white/40 flex items-center justify-center font-bold text-lg overflow-hidden">
            {user.name[0]}
          </div>
          <button className="relative">
            <Bell size={22} />
            {notifications > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-destructive text-[10px] font-bold flex items-center justify-center">
                {notifications}
              </span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
