// Estado mockado interativo do MinhaUFAL
import { create } from "zustand";

export type Transaction = {
  id: string;
  type: "credit" | "debit";
  amount: number;
  description: string;
  date: string; // ISO
};

export type CardRequest = {
  id: string;
  type: "primeira_via" | "segunda_via";
  cpf: string;
  matricula: string;
  cardNumber?: string; // só na 2ª via
  reason?: string;
  date: string;
  status: "solicitado" | "em_producao" | "em_transporte" | "chega";
  transferredBalance?: number;
};

type Store = {
  user: { name: string; course: string; avatar?: string };
  balance: number;
  transactions: Transaction[];
  notifications: number;
  cardStatus: "solicitado" | "em_producao" | "em_transporte" | "chega"; // timeline
  cardNumber: string | null;
  hasCard: boolean;
  cardRequests: CardRequest[];
  addCredit: (amount: number, method: "PIX" | "Cartão") => void;
  consume: (amount: number, label: string) => void;
  requestFirstCard: (data: Omit<CardRequest, "id" | "type" | "date" | "status">) => void;
  reportLostCard: (data: { matricula: string; cardNumber: string; reason: string }) => number;
};

export const useApp = create<Store>((set, get) => ({
  user: { name: "Vitor", course: "Ciência da Computação" },
  balance: 24,
  notifications: 1,
  cardStatus: "em_transporte",
  cardNumber: "RFID-2026-008472",
  hasCard: true,
  cardRequests: [
    {
      id: "cr1",
      type: "primeira_via",
      cpf: "***.***.***-**",
      matricula: "20210045123",
      date: "2026-04-10T10:00:00",
      status: "em_transporte",
    },
  ],
  transactions: [
    { id: "t1", type: "debit", amount: 3, description: "Almoço RU - A.C. Simões", date: "2026-04-29T12:24:00" },
    { id: "t2", type: "credit", amount: 24, description: "Recarga via PIX", date: "2026-04-28T18:10:00" },
    { id: "t3", type: "debit", amount: 3, description: "Jantar RU - A.C. Simões", date: "2026-04-27T19:02:00" },
    { id: "t4", type: "debit", amount: 3, description: "Almoço RU - A.C. Simões", date: "2026-04-26T12:41:00" },
    { id: "t5", type: "credit", amount: 50, description: "Recarga via Cartão", date: "2026-04-20T09:30:00" },
  ],
  addCredit: (amount, method) =>
    set((s) => ({
      balance: s.balance + amount,
      transactions: [
        {
          id: `t${Date.now()}`,
          type: "credit",
          amount,
          description: `Recarga via ${method}`,
          date: new Date().toISOString(),
        },
        ...s.transactions,
      ],
    })),
  consume: (amount, label) =>
    set((s) => ({
      balance: Math.max(0, s.balance - amount),
      transactions: [
        {
          id: `t${Date.now()}`,
          type: "debit",
          amount,
          description: label,
          date: new Date().toISOString(),
        },
        ...s.transactions,
      ],
    })),
  requestFirstCard: (data) =>
    set((s) => ({
      cardRequests: [
        {
          id: `cr${Date.now()}`,
          type: "primeira_via",
          date: new Date().toISOString(),
          status: "solicitado",
          ...data,
        },
        ...s.cardRequests,
      ],
      cardStatus: "solicitado",
      hasCard: false,
    })),
  reportLostCard: ({ matricula, cardNumber, reason }) => {
    const transferred = get().balance;
    const newCardNumber = `RFID-2026-${Math.floor(100000 + Math.random() * 899999)}`;
    set((s) => ({
      cardNumber: newCardNumber,
      cardStatus: "solicitado",
      hasCard: false,
      cardRequests: [
        {
          id: `cr${Date.now()}`,
          type: "segunda_via",
          cpf: "***.***.***-**",
          matricula,
          cardNumber,
          reason,
          date: new Date().toISOString(),
          status: "solicitado",
          transferredBalance: transferred,
        },
        ...s.cardRequests,
      ],
      transactions: [
        {
          id: `t${Date.now()}`,
          type: "credit",
          amount: 0,
          description: `Saldo R$ ${transferred.toFixed(2).replace(".", ",")} transferido para o novo cartão`,
          date: new Date().toISOString(),
        },
        ...s.transactions,
      ],
    }));
    return transferred;
  },
}));

// Dashboard data
export const monthlyAvg = [
  { mes: "Jan", almocos: 18 },
  { mes: "Fev", almocos: 22 },
  { mes: "Mar", almocos: 26 },
  { mes: "Abr", almocos: 31 },
  { mes: "Mai", almocos: 28 },
  { mes: "Jun", almocos: 24 },
];

export const evasao = [
  { dia: "Seg", evasao: 4 },
  { dia: "Ter", evasao: 3 },
  { dia: "Qua", evasao: 8 },
  { dia: "Qui", evasao: 5 },
  { dia: "Sex", evasao: 12 },
  { dia: "Sáb", evasao: 18 },
  { dia: "Dom", evasao: 22 },
];

export const freqCurso = [
  { curso: "C. Comp.", freq: 89 },
  { curso: "Eng.", freq: 76 },
  { curso: "Med.", freq: 42 },
  { curso: "Direito", freq: 65 },
  { curso: "Letras", freq: 51 },
];

export const filaHorario = [
  { hora: "11:00", pessoas: 18 },
  { hora: "11:15", pessoas: 32 },
  { hora: "11:30", pessoas: 78 },
  { hora: "11:45", pessoas: 124 },
  { hora: "12:00", pessoas: 156 },
  { hora: "12:15", pessoas: 142 },
  { hora: "12:30", pessoas: 98 },
  { hora: "12:45", pessoas: 64 },
  { hora: "13:00", pessoas: 41 },
  { hora: "13:15", pessoas: 22 },
];

export const insights = [
  {
    id: "top",
    title: "Você é TOP 1%",
    text: "Está entre os 1% que mais comem no RU em 2026. Parabéns, frequentador raiz! 🏆",
    emoji: "🏆",
    accent: "from-amber-400 to-orange-500",
  },
  {
    id: "vezes",
    title: "Você almoçou 343 vezes",
    text: "Isso dá 1.029 reais economizados comparado a um restaurante comum.",
    emoji: "🍽️",
    accent: "from-primary to-primary-deep",
  },
  {
    id: "dia",
    title: "Seu dia favorito é segunda",
    text: "Você apareceu 47 segundas-feiras este ano. Começar a semana bem alimentado, né?",
    emoji: "📅",
    accent: "from-emerald-400 to-teal-600",
  },
  {
    id: "anim",
    title: "Seu animal interior é…",
    text: "🐺 Lobo solitário do almoço — você prefere chegar 11h45, antes da multidão.",
    emoji: "🐺",
    accent: "from-violet-500 to-fuchsia-600",
  },
  {
    id: "gastou",
    title: "Quando você gastou 500 reais",
    text: "Você gasta 33% menos que outros usuários do mesmo curso.",
    emoji: "💸",
    accent: "from-rose-400 to-pink-600",
  },
];

export const instagramPosts = [
  { id: 1, img: "🍛", title: "Cardápio de hoje", likes: 234, time: "2h" },
  { id: 2, img: "🥗", title: "Opção vegetariana", likes: 189, time: "5h" },
  { id: 3, img: "🍰", title: "Sobremesa especial", likes: 412, time: "1d" },
  { id: 4, img: "🍲", title: "Sopa do dia", likes: 87, time: "2d" },
  { id: 5, img: "🥙", title: "Lanche da tarde", likes: 156, time: "3d" },
  { id: 6, img: "🍝", title: "Massa ao molho", likes: 298, time: "4d" },
];

export const cardSteps = [
  { key: "solicitado", label: "Solicitado", date: "10/04/2026" },
  { key: "em_producao", label: "Em produção", date: "15/04/2026" },
  { key: "em_transporte", label: "Em transporte", date: "26/04/2026" },
  { key: "chega", label: "Disponível para retirada", date: "—" },
] as const;
