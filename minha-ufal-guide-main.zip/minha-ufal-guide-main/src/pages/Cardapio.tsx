import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";

const cardapio = {
  almoco: {
    titulo: "Almoço",
    horario: "11:00 às 14:00",
    itens: [
      { nome: "Arroz branco", icon: "🍚" },
      { nome: "Feijão carioca", icon: "🫘" },
      { nome: "Bife acebolado", icon: "🥩" },
      { nome: "Opção veg: legumes ao forno", icon: "🥦" },
      { nome: "Salada: alface, tomate, cenoura", icon: "🥗" },
      { nome: "Suco de acerola", icon: "🥤" },
      { nome: "Sobremesa: gelatina", icon: "🍮" },
    ],
  },
  jantar: {
    titulo: "Jantar",
    horario: "17:30 às 19:30",
    itens: [
      { nome: "Arroz integral", icon: "🍚" },
      { nome: "Feijão preto", icon: "🫘" },
      { nome: "Frango grelhado", icon: "🍗" },
      { nome: "Opção veg: estrogonofe de grão-de-bico", icon: "🍲" },
      { nome: "Salada: rúcula, beterraba", icon: "🥗" },
      { nome: "Suco de maracujá", icon: "🥤" },
      { nome: "Sobremesa: banana", icon: "🍌" },
    ],
  },
};

export default function Cardapio() {
  return (
    <MobileShell>
      <HeroHeader title="Cardápio" subtitle="Quinta-feira, 30/04" showBack compact />

      <div className="px-5 -mt-6 space-y-4 pb-6">
        {[cardapio.almoco, cardapio.jantar].map((m, idx) => (
          <div
            key={m.titulo}
            style={{ animationDelay: `${idx * 100}ms` }}
            className="bg-card rounded-2xl shadow-card overflow-hidden animate-float-in"
          >
            <div className="bg-gradient-card-blue px-5 py-3 flex items-center justify-between">
              <h2 className="font-bold text-primary-deep">{m.titulo}</h2>
              <span className="text-xs font-semibold text-primary-deep/70">{m.horario}</span>
            </div>
            <ul className="divide-y divide-border">
              {m.itens.map((it) => (
                <li key={it.nome} className="px-5 py-3 flex items-center gap-3">
                  <span className="text-xl">{it.icon}</span>
                  <span className="text-sm">{it.nome}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </MobileShell>
  );
}
