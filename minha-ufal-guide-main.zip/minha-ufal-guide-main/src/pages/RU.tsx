import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useNavigate } from "react-router-dom";
import { useApp } from "@/lib/mockData";
import {
  Wallet,
  Utensils,
  MessageCircle,
  RotateCw,
  History,
  CreditCard,
  ChevronRight,
  Plus,
  Users2,
  BarChart3,
  Truck,
} from "lucide-react";

const items = [
  {
    title: "Extrato",
    desc: "Compre, consulte e acompanhe a utilização de suas fichas",
    Icon: Wallet,
    to: "/extrato",
  },
  {
    title: "Cardápio",
    desc: "Acesse o cardápio diário de almoço e jantar",
    Icon: Utensils,
    to: "/cardapio",
  },
  {
    title: "Fale com o RU",
    desc: "Deixe suas sugestões, críticas ou elogios",
    Icon: MessageCircle,
    to: "/fale",
  },
  {
    title: "Solicitar reembolso",
    desc: "Solicitar devolução do saldo",
    Icon: RotateCw,
    to: "#",
  },
  {
    title: "Histórico de solicitações",
    desc: "Acompanhe seus pedidos de reembolso",
    Icon: History,
    to: "#",
  },
  {
    title: "Carteirinha RFID",
    desc: "Solicitar 1ª via ou reportar perda do cartão",
    Icon: CreditCard,
    to: "/carteirinha",
    badge: "Principal",
  },
  {
    title: "Acompanhar cartão",
    desc: "Veja o status do seu cartão RFID",
    Icon: Truck,
    to: "/cartao",
    badge: "Em transporte",
  },
  {
    title: "Fila em tempo real",
    desc: "Quantas pessoas estão no RU agora",
    Icon: Users2,
    to: "/fila",
    badge: "98 agora",
  },
  {
    title: "Meu painel RU",
    desc: "Estatísticas e insights da sua jornada",
    Icon: BarChart3,
    to: "/dashboard",
  },
];

export default function RU() {
  const navigate = useNavigate();
  const { balance } = useApp();

  return (
    <MobileShell>
      <HeroHeader showLogo showBack />

      <div className="px-5 -mt-10">
        <button
          onClick={() => navigate("/adicionar")}
          className="w-full text-left bg-card rounded-2xl shadow-card p-5 transition-spring hover:shadow-elevated animate-float-in"
        >
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground">Saldo Disponível</span>
            <ChevronRight size={20} className="text-muted-foreground" />
          </div>
          <div className="flex items-center justify-between mt-2">
            <span className="text-3xl font-black">
              R$ {balance.toFixed(2).replace(".", ",")}
            </span>
            <span className="bg-gradient-accent text-accent-foreground px-4 py-2.5 rounded-full font-bold text-sm flex items-center gap-1.5 shadow-accent">
              <Plus size={16} strokeWidth={3} />
              Adicionar R$
            </span>
          </div>
        </button>
      </div>

      <div className="px-5 mt-5">
        <div className="bg-card rounded-2xl shadow-card divide-y divide-border overflow-hidden">
          {items.map((it, i) => (
            <button
              key={it.title}
              onClick={() => it.to !== "#" && navigate(it.to)}
              style={{ animationDelay: `${i * 40}ms` }}
              className="w-full flex items-start gap-4 p-4 text-left hover:bg-muted/50 transition-smooth animate-slide-up"
            >
              <div className="w-12 h-12 rounded-xl bg-primary-soft flex items-center justify-center text-primary shrink-0">
                <it.Icon size={22} strokeWidth={1.8} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <h3 className="font-bold">{it.title}</h3>
                  {it.badge && (
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-accent/10 text-accent">
                      {it.badge}
                    </span>
                  )}
                </div>
                <p className="text-sm text-muted-foreground leading-snug mt-0.5">
                  {it.desc}
                </p>
              </div>
              <ChevronRight size={20} className="text-muted-foreground/50 mt-3 shrink-0" />
            </button>
          ))}
        </div>
      </div>

      <p className="text-center text-[11px] text-muted-foreground py-5">
        © 2026 PROTIC/UFDPar — Licenciado para UFAL
      </p>
    </MobileShell>
  );
}
