import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { filaHorario } from "@/lib/mockData";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid, ReferenceDot } from "recharts";
import { Clock, Users2, TrendingUp } from "lucide-react";
import { useEffect, useState } from "react";

export default function Fila() {
  const [pessoas, setPessoas] = useState(98);

  // simula atualização em tempo real
  useEffect(() => {
    const id = setInterval(() => {
      setPessoas((p) => Math.max(20, Math.min(180, p + Math.round((Math.random() - 0.5) * 14))));
    }, 2500);
    return () => clearInterval(id);
  }, []);

  const status =
    pessoas < 50
      ? { label: "Tranquilo", color: "text-success", bg: "bg-success" }
      : pessoas < 110
      ? { label: "Movimentado", color: "text-warning", bg: "bg-warning" }
      : { label: "Lotado", color: "text-destructive", bg: "bg-destructive" };

  const media = Math.round(filaHorario.reduce((a, x) => a + x.pessoas, 0) / filaHorario.length);

  return (
    <MobileShell>
      <HeroHeader title="Fila do RU" subtitle="Atualizado agora" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-6 text-center animate-float-in relative overflow-hidden">
          <div className="flex items-center justify-center gap-2 mb-2">
            <span className="relative flex h-3 w-3">
              <span className={`absolute inline-flex h-full w-full rounded-full ${status.bg} opacity-60 animate-pulse-ring`} />
              <span className={`relative inline-flex rounded-full h-3 w-3 ${status.bg}`} />
            </span>
            <span className={`text-xs font-bold uppercase tracking-wider ${status.color}`}>
              {status.label}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">Olá, Vitor</p>
          <p className="mt-1 text-base">A fila nesse momento está com</p>
          <div className="my-3 flex items-baseline justify-center gap-2">
            <Users2 className="text-primary" size={32} />
            <span key={pessoas} className="text-6xl font-black text-primary animate-count-up">
              {pessoas}
            </span>
            <span className="text-lg text-muted-foreground font-semibold">pessoas</span>
          </div>
          <p className="text-xs text-muted-foreground">
            A média nesse horário é de <span className="font-bold text-foreground">{media} pessoas</span>
          </p>
        </div>
      </div>

      <div className="px-5 mt-4 grid grid-cols-3 gap-2">
        <Stat Icon={Clock} label="Espera estimada" value={`${Math.round(pessoas / 12)} min`} />
        <Stat Icon={Users2} label="No RU agora" value={`${pessoas}`} />
        <Stat Icon={TrendingUp} label="Vs média" value={`${pessoas > media ? "+" : ""}${pessoas - media}`} />
      </div>

      <div className="px-5 mt-5 mb-6">
        <div className="bg-card rounded-2xl shadow-card p-4 animate-float-in">
          <h3 className="font-bold text-sm mb-1">Pessoas por horário</h3>
          <p className="text-xs text-muted-foreground mb-3">Hoje, almoço</p>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={filaHorario}>
              <defs>
                <linearGradient id="fillFila" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="hsl(var(--primary))" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="hora" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  borderRadius: 12,
                  border: "1px solid hsl(var(--border))",
                  fontSize: 12,
                }}
              />
              <Area
                type="monotone"
                dataKey="pessoas"
                stroke="hsl(var(--primary))"
                strokeWidth={2.5}
                fill="url(#fillFila)"
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-3 p-3 rounded-xl bg-primary-soft text-primary-deep text-xs">
            💡 <strong>Dica:</strong> chegue antes das 11:30 ou depois das 12:45 para evitar fila.
          </div>
        </div>
      </div>
    </MobileShell>
  );
}

function Stat({ Icon, label, value }: any) {
  return (
    <div className="bg-card rounded-xl shadow-card p-3">
      <Icon size={16} className="text-primary mb-1" />
      <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold leading-tight">
        {label}
      </p>
      <p className="text-base font-black mt-0.5">{value}</p>
    </div>
  );
}
