import { useState } from "react";
import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useApp } from "@/lib/mockData";
import { useNavigate } from "react-router-dom";
import { CreditCard, Smartphone, Check } from "lucide-react";
import { toast } from "sonner";

const presets = [3, 10, 24, 50];

export default function Adicionar() {
  const { addCredit, balance } = useApp();
  const navigate = useNavigate();
  const [amount, setAmount] = useState<number>(10);
  const [custom, setCustom] = useState("");
  const [method, setMethod] = useState<"PIX" | "Cartão">("PIX");
  const [done, setDone] = useState(false);

  const finalAmount = custom ? parseFloat(custom.replace(",", ".")) || 0 : amount;

  const handlePay = () => {
    if (finalAmount <= 0) return;
    addCredit(finalAmount, method);
    setDone(true);
    toast.success(`R$ ${finalAmount.toFixed(2)} adicionados via ${method}!`);
    setTimeout(() => navigate("/ru"), 1400);
  };

  return (
    <MobileShell>
      <HeroHeader title="Adicionar créditos" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
            Saldo atual
          </p>
          <p className="text-2xl font-black">R$ {balance.toFixed(2).replace(".", ",")}</p>

          <div className="mt-5">
            <p className="text-sm font-semibold mb-2">Escolha um valor</p>
            <div className="grid grid-cols-2 gap-2">
              {presets.map((v) => (
                <button
                  key={v}
                  onClick={() => {
                    setAmount(v);
                    setCustom("");
                  }}
                  className={`py-3 rounded-xl font-bold border-2 transition-smooth ${
                    !custom && amount === v
                      ? "border-primary bg-primary-soft text-primary"
                      : "border-border bg-background hover:border-primary/40"
                  }`}
                >
                  R$ {v.toFixed(2).replace(".", ",")}
                </button>
              ))}
            </div>
          </div>

          <div className="mt-4">
            <p className="text-sm font-semibold mb-2">Ou digite outro valor</p>
            <div className="flex items-center gap-2 border-2 border-border rounded-xl px-3 py-2 focus-within:border-primary transition-smooth">
              <span className="text-muted-foreground font-semibold">R$</span>
              <input
                type="number"
                inputMode="decimal"
                placeholder="0,00"
                value={custom}
                onChange={(e) => setCustom(e.target.value)}
                className="flex-1 bg-transparent outline-none text-lg font-bold"
              />
            </div>
          </div>
        </div>

        <div className="mt-4 bg-card rounded-2xl shadow-card p-5">
          <p className="text-sm font-semibold mb-3">Forma de pagamento</p>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setMethod("PIX")}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl font-bold border-2 transition-smooth ${
                method === "PIX"
                  ? "border-primary bg-primary-soft text-primary"
                  : "border-border"
              }`}
            >
              <Smartphone size={18} /> PIX
            </button>
            <button
              onClick={() => setMethod("Cartão")}
              className={`flex items-center justify-center gap-2 py-3 rounded-xl font-bold border-2 transition-smooth ${
                method === "Cartão"
                  ? "border-primary bg-primary-soft text-primary"
                  : "border-border"
              }`}
            >
              <CreditCard size={18} /> Cartão
            </button>
          </div>
        </div>

        <div className="mt-5 flex gap-2 pb-6">
          <button
            onClick={() => navigate(-1)}
            className="flex-1 py-3.5 rounded-xl font-bold border-2 border-border"
          >
            Cancelar
          </button>
          <button
            disabled={finalAmount <= 0 || done}
            onClick={handlePay}
            className="flex-1 py-3.5 rounded-xl font-bold bg-gradient-accent text-accent-foreground shadow-accent disabled:opacity-50 transition-smooth flex items-center justify-center gap-2"
          >
            {done ? (
              <>
                <Check size={20} strokeWidth={3} /> Pago
              </>
            ) : (
              "Seguir para pagamento"
            )}
          </button>
        </div>
      </div>
    </MobileShell>
  );
}
