import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { instagramPosts } from "@/lib/mockData";
import { Heart, MessageCircle, Send, Bookmark } from "lucide-react";
import { useState } from "react";

export default function Instagram() {
  return (
    <MobileShell>
      <HeroHeader title="@ru.ufal" subtitle="Restaurante Universitário" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-4 animate-float-in">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-rose-500 via-fuchsia-500 to-amber-400 p-0.5">
              <div className="w-full h-full rounded-full bg-card flex items-center justify-center text-2xl">
                🍽️
              </div>
            </div>
            <div className="flex-1 grid grid-cols-3 gap-2 text-center">
              <Stat n="15" l="Posts" />
              <Stat n="2.068" l="Seguidores" />
              <Stat n="103" l="Seguindo" />
            </div>
          </div>
          <p className="text-sm font-semibold mt-3">RU UFAL · Maceió 🇧🇷</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            Cardápio diário, novidades e bastidores do Restaurante Universitário da UFAL.
          </p>
          <button className="mt-3 w-full py-2 rounded-lg bg-gradient-primary text-primary-foreground text-sm font-bold">
            Seguir
          </button>
        </div>
      </div>

      {/* Grid de posts */}
      <div className="px-5 mt-4 grid grid-cols-3 gap-1">
        {instagramPosts.map((p, i) => (
          <div
            key={p.id}
            style={{ animationDelay: `${i * 60}ms` }}
            className="aspect-square rounded-md bg-gradient-to-br from-primary-soft to-accent/20 flex items-center justify-center text-4xl shadow-card animate-slide-up"
          >
            {p.img}
          </div>
        ))}
      </div>

      {/* Feed */}
      <div className="px-5 mt-5 mb-6 space-y-4">
        {instagramPosts.slice(0, 3).map((p) => (
          <FeedPost key={p.id} post={p} />
        ))}
      </div>
    </MobileShell>
  );
}

function Stat({ n, l }: { n: string; l: string }) {
  return (
    <div>
      <p className="font-black">{n}</p>
      <p className="text-[10px] text-muted-foreground">{l}</p>
    </div>
  );
}

function FeedPost({ post }: { post: (typeof instagramPosts)[number] }) {
  const [liked, setLiked] = useState(false);
  const likes = post.likes + (liked ? 1 : 0);
  return (
    <div className="bg-card rounded-2xl shadow-card overflow-hidden animate-float-in">
      <div className="flex items-center gap-2 p-3">
        <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-rose-500 to-amber-400 p-0.5">
          <div className="w-full h-full rounded-full bg-card flex items-center justify-center text-sm">
            🍽️
          </div>
        </div>
        <span className="text-sm font-semibold flex-1">ru.ufal</span>
        <span className="text-xs text-muted-foreground">{post.time}</span>
      </div>
      <div className="aspect-square bg-gradient-to-br from-primary-soft via-accent/20 to-primary/30 flex items-center justify-center text-7xl">
        {post.img}
      </div>
      <div className="p-3">
        <div className="flex items-center gap-4">
          <button onClick={() => setLiked((l) => !l)}>
            <Heart
              size={22}
              className={liked ? "fill-destructive text-destructive" : ""}
            />
          </button>
          <button>
            <MessageCircle size={22} />
          </button>
          <button>
            <Send size={22} />
          </button>
          <button className="ml-auto">
            <Bookmark size={22} />
          </button>
        </div>
        <p className="text-sm font-bold mt-2">{likes.toLocaleString("pt-BR")} curtidas</p>
        <p className="text-sm mt-1">
          <span className="font-bold">ru.ufal</span> {post.title} — confira o cardápio completo no
          app MinhaUFAL! 🍴
        </p>
      </div>
    </div>
  );
}
