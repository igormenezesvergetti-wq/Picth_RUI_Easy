import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useApp, cardSteps } from "@/lib/mockData";
import { Check, Truck, Package, FileText, Hand } from "lucide-react";

const icons = {
  solicitado: FileText,
  em_producao: Package,
  em_transporte: Truck,
  chega: Hand,
} as const;

export default function Cartao() {
  const { cardStatus, user } = useApp();
  const currentIdx = cardSteps.findIndex((s) => s.key === cardStatus);

  return (
    <MobileShell>
      <HeroHeader title="Acompanhar cartão" subtitle="Status do seu RFID" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground">
              <Hand size={26} />
            </div>
            <div>
              <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">
                Cartão de
              </p>
              <p className="font-bold text-lg">{user.name}</p>
              <p className="text-xs text-muted-foreground">{user.course}</p>
            </div>
          </div>
        </div>

        <div className="mt-4 bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <h3 className="font-bold mb-4">Linha do tempo</h3>
          <div className="relative">
            {cardSteps.map((s, i) => {
              const Icon = icons[s.key];
              const completed = i < currentIdx;
              const current = i === currentIdx;
              const last = i === cardSteps.length - 1;
              return (
                <div key={s.key} className="flex gap-4 pb-6 relative animate-slide-up" style={{ animationDelay: `${i * 100}ms` }}>
                  {!last && (
                    <div
                      className={`absolute left-5 top-10 bottom-0 w-0.5 ${
                        completed ? "bg-success" : "bg-border"
                      }`}
                    />
                  )}
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 z-10 transition-spring ${
                      completed
                        ? "bg-success text-success-foreground"
                        : current
                        ? "bg-gradient-primary text-primary-foreground shadow-elevated scale-110"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {completed ? <Check size={20} strokeWidth={3} /> : <Icon size={18} />}
                    {current && (
                      <span className="absolute inset-0 rounded-full bg-primary opacity-40 animate-pulse-ring" />
                    )}
                  </div>
                  <div className="flex-1 pt-1.5">
                    <p
                      className={`font-bold text-sm ${
                        current ? "text-primary" : completed ? "" : "text-muted-foreground"
                      }`}
                    >
                      {s.label}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">{s.date}</p>
                    {current && (
                      <p className="text-xs mt-2 p-2 rounded-lg bg-primary-soft text-primary-deep">
                        Seu cartão está a caminho! Previsão de chegada em 2-3 dias úteis.
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 mb-6 p-4 rounded-2xl bg-gradient-card-blue text-primary-deep text-sm flex gap-3">
          <span className="text-2xl">📍</span>
          <div>
            <p className="font-bold">Local de retirada</p>
            <p className="text-xs mt-1 opacity-80">
              Secretaria do RU — A.C. Simões, das 9h às 16h. Leve um documento com foto.
            </p>
          </div>
        </div>
      </div>
    </MobileShell>
  );
}
