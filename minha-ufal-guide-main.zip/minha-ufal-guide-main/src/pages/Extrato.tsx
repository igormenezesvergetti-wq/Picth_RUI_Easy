import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useApp } from "@/lib/mockData";
import { ArrowDownLeft, ArrowUpRight } from "lucide-react";

export default function Extrato() {
  const { transactions, balance } = useApp();

  const credits = transactions.filter((t) => t.type === "credit");
  const debits = transactions.filter((t) => t.type === "debit");
  const totalCredits = credits.reduce((a, t) => a + t.amount, 0);
  const totalDebits = debits.reduce((a, t) => a + t.amount, 0);

  return (
    <MobileShell>
      <HeroHeader title="Extrato" subtitle="Abril / 2026" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Saldo
              </p>
              <p className="text-lg font-black mt-1">
                R$ {balance.toFixed(2).replace(".", ",")}
              </p>
            </div>
            <div className="border-x border-border">
              <p className="text-[10px] uppercase tracking-wider text-success">Créditos</p>
              <p className="text-lg font-black mt-1 text-success">
                +{totalCredits.toFixed(2).replace(".", ",")}
              </p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-wider text-destructive">Débitos</p>
              <p className="text-lg font-black mt-1 text-destructive">
                −{totalDebits.toFixed(2).replace(".", ",")}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="px-5 mt-5 space-y-2 pb-6">
        <h3 className="text-sm font-bold text-muted-foreground uppercase tracking-wider px-2">
          Transações
        </h3>
        {transactions.map((t, i) => {
          const isCredit = t.type === "credit";
          const d = new Date(t.date);
          return (
            <div
              key={t.id}
              style={{ animationDelay: `${i * 50}ms` }}
              className="bg-card rounded-xl shadow-card p-3 flex items-center gap-3 animate-slide-up"
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${
                  isCredit ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
                }`}
              >
                {isCredit ? <ArrowDownLeft size={20} /> : <ArrowUpRight size={20} />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{t.description}</p>
                <p className="text-[11px] text-muted-foreground">
                  {d.toLocaleDateString("pt-BR")} ·{" "}
                  {d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
                </p>
              </div>
              <span
                className={`font-bold ${isCredit ? "text-success" : "text-destructive"}`}
              >
                {isCredit ? "+" : "−"}R$ {t.amount.toFixed(2).replace(".", ",")}
              </span>
            </div>
          );
        })}
      </div>
    </MobileShell>
  );
}
