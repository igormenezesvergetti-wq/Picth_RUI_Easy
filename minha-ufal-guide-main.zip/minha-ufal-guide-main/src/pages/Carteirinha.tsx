import { useState } from "react";
import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useApp } from "@/lib/mockData";
import { useNavigate } from "react-router-dom";
import { CreditCard, AlertTriangle, Check, ShieldAlert, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const onlyDigits = (s: string) => s.replace(/\D/g, "");

const formatCPF = (v: string) =>
  onlyDigits(v)
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");

const firstSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(3, "Informe seu nome completo")
    .max(120, "Nome muito longo"),
  cpf: z
    .string()
    .transform(onlyDigits)
    .refine((v) => v.length === 11, "CPF deve ter 11 dígitos"),
  matricula: z
    .string()
    .transform(onlyDigits)
    .refine((v) => v.length >= 6 && v.length <= 14, "Matrícula inválida"),
  course: z.string().trim().min(2, "Informe seu curso").max(80),
  email: z.string().trim().email("E-mail inválido").max(160),
});

const lostSchema = z.object({
  matricula: z
    .string()
    .transform(onlyDigits)
    .refine((v) => v.length >= 6 && v.length <= 14, "Matrícula inválida"),
  cardNumber: z
    .string()
    .trim()
    .min(6, "Informe o número do cartão (ou só a matrícula acima)")
    .max(40, "Número de cartão inválido"),
  reason: z.string().trim().min(5, "Descreva brevemente o ocorrido").max(300),
  confirm: z.literal(true, {
    errorMap: () => ({ message: "Você precisa confirmar para cancelar o cartão" }),
  }),
});

type Tab = "solicitar" | "perda";

export default function Carteirinha() {
  const navigate = useNavigate();
  const { hasCard, cardNumber, balance, requestFirstCard, reportLostCard } = useApp();
  const [tab, setTab] = useState<Tab>(hasCard ? "perda" : "solicitar");

  return (
    <MobileShell>
      <HeroHeader title="Carteirinha RFID" subtitle="Forma de pagamento do RU" showBack compact />

      <div className="px-5 -mt-6">
        {/* Card status atual */}
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center text-primary-foreground shrink-0">
              <CreditCard size={22} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
                Cartão atual
              </p>
              <p className="font-bold truncate">{cardNumber ?? "Nenhum cartão ativo"}</p>
              <p className="text-xs text-muted-foreground">
                Saldo: R$ {balance.toFixed(2).replace(".", ",")}
              </p>
            </div>
            {hasCard ? (
              <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-success/15 text-success">
                Ativo
              </span>
            ) : (
              <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-warning/15 text-warning">
                Sem cartão
              </span>
            )}
          </div>
        </div>

        {/* Tabs */}
        <div className="mt-4 grid grid-cols-2 bg-muted rounded-xl p-1">
          <TabBtn active={tab === "solicitar"} onClick={() => setTab("solicitar")}>
            Solicitar 1ª via
          </TabBtn>
          <TabBtn active={tab === "perda"} onClick={() => setTab("perda")}>
            Perda / 2ª via
          </TabBtn>
        </div>

        <div className="mt-4 pb-6">
          {tab === "solicitar" ? (
            <FirstCardForm
              onSubmit={(data) => {
                requestFirstCard({
                  cpf: formatCPF(data.cpf),
                  matricula: data.matricula,
                });
                toast.success("Solicitação de carteirinha enviada!");
                navigate("/cartao");
              }}
            />
          ) : (
            <LostCardForm
              hasCard={hasCard}
              onSubmit={(data) => {
                const transferred = reportLostCard({
                  matricula: data.matricula,
                  cardNumber: data.cardNumber,
                  reason: data.reason,
                });
                toast.success(
                  `Cartão cancelado. R$ ${transferred
                    .toFixed(2)
                    .replace(".", ",")} serão transferidos para o novo cartão.`
                );
                navigate("/cartao");
              }}
            />
          )}
        </div>
      </div>
    </MobileShell>
  );
}

function TabBtn({
  children,
  active,
  onClick,
}: {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`py-2.5 rounded-lg text-sm font-bold transition-smooth ${
        active ? "bg-card shadow-card text-primary" : "text-muted-foreground"
      }`}
    >
      {children}
    </button>
  );
}

/* ---------- Form: 1ª via ---------- */

function FirstCardForm({ onSubmit }: { onSubmit: (d: any) => void }) {
  const [values, setValues] = useState({
    fullName: "Vitor Souza",
    cpf: "",
    matricula: "",
    course: "Ciência da Computação",
    email: "vitor@academico.ufal.br",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (k: string, v: string) => setValues((s) => ({ ...s, [k]: v }));

  const submit = () => {
    const parsed = firstSchema.safeParse(values);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    onSubmit(parsed.data);
  };

  return (
    <div className="bg-card rounded-2xl shadow-card p-5 space-y-4 animate-float-in">
      <div className="flex gap-3 p-3 rounded-xl bg-primary-soft text-primary-deep">
        <CreditCard className="shrink-0 mt-0.5" size={18} />
        <p className="text-xs leading-snug">
          Preencha seus dados para solicitar sua carteirinha RFID. Após aprovação, você será
          notificado para retirá-la na secretaria do RU.
        </p>
      </div>

      <Field
        label="Nome completo"
        value={values.fullName}
        onChange={(v) => set("fullName", v)}
        error={errors.fullName}
        maxLength={120}
      />
      <Field
        label="CPF"
        value={values.cpf}
        onChange={(v) => set("cpf", formatCPF(v))}
        placeholder="000.000.000-00"
        inputMode="numeric"
        error={errors.cpf}
        maxLength={14}
      />
      <Field
        label="Número de matrícula"
        value={values.matricula}
        onChange={(v) => set("matricula", onlyDigits(v).slice(0, 14))}
        placeholder="Ex: 20210045123"
        inputMode="numeric"
        error={errors.matricula}
        maxLength={14}
      />
      <Field
        label="Curso"
        value={values.course}
        onChange={(v) => set("course", v)}
        error={errors.course}
        maxLength={80}
      />
      <Field
        label="E-mail acadêmico"
        value={values.email}
        onChange={(v) => set("email", v)}
        placeholder="seu.nome@academico.ufal.br"
        error={errors.email}
        maxLength={160}
      />

      <button
        onClick={submit}
        className="w-full py-3.5 rounded-xl font-bold bg-gradient-primary text-primary-foreground shadow-elevated flex items-center justify-center gap-2"
      >
        Solicitar carteirinha <ArrowRight size={18} />
      </button>
    </div>
  );
}

/* ---------- Form: perda / 2ª via ---------- */

function LostCardForm({
  hasCard,
  onSubmit,
}: {
  hasCard: boolean;
  onSubmit: (d: { matricula: string; cardNumber: string; reason: string }) => void;
}) {
  const { balance, cardNumber } = useApp();
  const [values, setValues] = useState({
    matricula: "",
    cardNumber: cardNumber ?? "",
    reason: "",
    confirm: false,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const set = (k: string, v: any) => setValues((s) => ({ ...s, [k]: v }));

  const submit = () => {
    const parsed = lostSchema.safeParse(values);
    if (!parsed.success) {
      const errs: Record<string, string> = {};
      parsed.error.issues.forEach((i) => (errs[i.path[0] as string] = i.message));
      setErrors(errs);
      return;
    }
    setErrors({});
    onSubmit({
      matricula: parsed.data.matricula!,
      cardNumber: parsed.data.cardNumber!,
      reason: parsed.data.reason!,
    });
  };

  if (!hasCard) {
    return (
      <div className="bg-card rounded-2xl shadow-card p-6 text-center animate-float-in">
        <div className="w-14 h-14 mx-auto rounded-full bg-warning/15 text-warning flex items-center justify-center mb-3">
          <ShieldAlert size={26} />
        </div>
        <h3 className="font-bold">Você ainda não tem um cartão ativo</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Solicite sua 1ª via na aba ao lado.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-float-in">
      {/* Aviso de saldo */}
      <div className="p-4 rounded-2xl bg-gradient-card-blue text-primary-deep">
        <div className="flex gap-3">
          <Check className="shrink-0 mt-0.5" size={20} />
          <div className="text-sm">
            <p className="font-bold">Seu saldo está protegido</p>
            <p className="text-xs mt-1 opacity-80">
              Os <strong>R$ {balance.toFixed(2).replace(".", ",")}</strong> do cartão atual serão
              transferidos automaticamente para o novo cartão após a emissão.
            </p>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-2xl shadow-card p-5 space-y-4">
        <div className="flex gap-3 p-3 rounded-xl bg-destructive/10 text-destructive">
          <AlertTriangle className="shrink-0 mt-0.5" size={18} />
          <p className="text-xs leading-snug">
            Ao confirmar, o cartão atual será <strong>cancelado imediatamente</strong> e não
            poderá ser reativado. Uma 2ª via será solicitada em seu nome.
          </p>
        </div>

        <Field
          label="Número de matrícula"
          value={values.matricula}
          onChange={(v) => set("matricula", onlyDigits(v).slice(0, 14))}
          placeholder="Ex: 20210045123"
          inputMode="numeric"
          error={errors.matricula}
          maxLength={14}
        />
        <Field
          label="Número do cartão perdido"
          value={values.cardNumber}
          onChange={(v) => set("cardNumber", v.toUpperCase().slice(0, 40))}
          placeholder="RFID-AAAA-NNNNNN"
          error={errors.cardNumber}
          maxLength={40}
        />
        <div>
          <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
            O que aconteceu?
          </label>
          <textarea
            value={values.reason}
            onChange={(e) => set("reason", e.target.value.slice(0, 300))}
            rows={3}
            maxLength={300}
            placeholder="Ex: perdi no campus, foi roubado, danificado..."
            className="mt-1.5 w-full border-2 border-border rounded-xl p-3 focus:border-primary outline-none resize-none transition-smooth text-sm"
          />
          {errors.reason && <p className="text-xs text-destructive mt-1">{errors.reason}</p>}
        </div>

        <label className="flex items-start gap-3 cursor-pointer p-3 rounded-xl border-2 border-border hover:border-primary/40 transition-smooth">
          <input
            type="checkbox"
            checked={values.confirm}
            onChange={(e) => set("confirm", e.target.checked)}
            className="mt-0.5 w-5 h-5 accent-destructive"
          />
          <span className="text-xs leading-snug">
            Confirmo que perdi o cartão e desejo cancelá-lo. Estou ciente de que esta ação é
            irreversível.
          </span>
        </label>
        {errors.confirm && <p className="text-xs text-destructive">{errors.confirm}</p>}

        <button
          onClick={submit}
          className="w-full py-3.5 rounded-xl font-bold bg-destructive text-destructive-foreground shadow-elevated flex items-center justify-center gap-2"
        >
          Cancelar cartão e solicitar 2ª via
        </button>
      </div>
    </div>
  );
}

/* ---------- Reusable field ---------- */

function Field({
  label,
  value,
  onChange,
  placeholder,
  error,
  inputMode,
  maxLength,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  error?: string;
  inputMode?: "numeric" | "text" | "decimal" | "email";
  maxLength?: number;
}) {
  return (
    <div>
      <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
        {label}
      </label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        inputMode={inputMode}
        maxLength={maxLength}
        className={`mt-1.5 w-full border-2 rounded-xl px-3 py-2.5 outline-none transition-smooth text-sm ${
          error ? "border-destructive" : "border-border focus:border-primary"
        }`}
      />
      {error && <p className="text-xs text-destructive mt-1">{error}</p>}
    </div>
  );
}
