import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { useNavigate } from "react-router-dom";
import { Sparkles, BarChart3, Users2 } from "lucide-react";

const apps = [
  {
    id: "ru",
    badge: "App",
    label: "Restaurante Universitário",
    isNew: true,
    to: "/ru",
    accent: "bg-primary-soft text-primary",
    emoji: "🍽️",
  },
  {
    id: "ascom",
    badge: "App",
    label: "Assessoria de Comunicação",
    isNew: true,
    to: "#",
    accent: "bg-orange-100 text-orange-700",
    emoji: "📣",
  },
  {
    id: "chatbot",
    badge: "Web",
    label: "Chatbot UFAL",
    to: "#",
    accent: "bg-violet-100 text-violet-700",
    emoji: "🤖",
  },
  {
    id: "fila",
    badge: "App",
    label: "Fila do RU agora",
    isNew: true,
    to: "/fila",
    accent: "bg-emerald-100 text-emerald-700",
    emoji: "👥",
  },
  {
    id: "dash",
    badge: "App",
    label: "Meu painel RU",
    isNew: true,
    to: "/dashboard",
    accent: "bg-pink-100 text-pink-700",
    emoji: "📊",
  },
  {
    id: "insta",
    badge: "Social",
    label: "Instagram do RU",
    to: "/instagram",
    accent: "bg-rose-100 text-rose-700",
    emoji: "📸",
  },
];

export default function Index() {
  const navigate = useNavigate();
  return (
    <MobileShell>
      <HeroHeader showLogo />

      <div className="px-5 -mt-9">
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <h2 className="text-xl font-bold">Seja bem-vindo(a)</h2>
          <p className="text-muted-foreground mt-1">ao aplicativo MinhaUFAL!</p>
        </div>
      </div>

      <div className="px-5 mt-6 grid grid-cols-2 gap-3">
        {apps.map((a, i) => (
          <button
            key={a.id}
            onClick={() => a.to !== "#" && navigate(a.to)}
            style={{ animationDelay: `${i * 60}ms` }}
            className="text-left bg-card rounded-2xl p-4 shadow-card hover:shadow-elevated transition-spring hover:-translate-y-1 animate-slide-up"
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-accent text-sm font-bold">{a.badge}</span>
              {a.isNew && (
                <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-primary-soft text-primary">
                  Novo!
                </span>
              )}
            </div>
            <div
              className={`w-14 h-14 rounded-xl ${a.accent} flex items-center justify-center text-2xl mb-3`}
            >
              {a.emoji}
            </div>
            <p className="text-sm font-semibold leading-tight">{a.label}</p>
          </button>
        ))}
      </div>

      <div className="px-5 mt-6 mb-4">
        <div className="bg-gradient-card-blue rounded-2xl p-4 flex items-center gap-3">
          <Sparkles className="text-primary shrink-0" size={28} />
          <div>
            <p className="text-sm font-semibold text-primary-deep">Você está no top 1%!</p>
            <p className="text-xs text-muted-foreground">
              Veja seus insights no painel do RU.
            </p>
          </div>
        </div>
      </div>

      <div className="px-5 mt-2 flex items-center justify-center gap-3 py-4 border-t border-border">
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
          UFAL
        </div>
        <div className="w-px h-4 bg-border" />
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
          NTI
        </div>
      </div>
      <p className="text-center text-[11px] text-muted-foreground pb-4">
        © 2026 PROTIC/UFDPar — Licenciado para UFAL
      </p>
    </MobileShell>
  );
}
