import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { monthlyAvg, evasao, freqCurso, insights } from "@/lib/mockData";
import { TrendingUp, TrendingDown } from "lucide-react";

export default function Dashboard() {
  return (
    <MobileShell>
      <HeroHeader title="Meu painel RU" subtitle="Suas estatísticas em 2026" showBack compact />

      {/* Insights gamificados (carrossel horizontal) */}
      <div className="px-5 -mt-6">
        <div className="flex gap-3 overflow-x-auto pb-2 -mx-5 px-5 snap-x snap-mandatory scrollbar-none">
          {insights.map((ins, i) => (
            <div
              key={ins.id}
              style={{ animationDelay: `${i * 80}ms` }}
              className={`min-w-[78%] snap-center rounded-2xl p-5 text-white shadow-elevated bg-gradient-to-br ${ins.accent} animate-float-in`}
            >
              <div className="text-3xl mb-2">{ins.emoji}</div>
              <h3 className="font-black text-lg leading-tight">{ins.title}</h3>
              <p className="text-sm mt-2 opacity-95 leading-snug">{ins.text}</p>
            </div>
          ))}
        </div>
      </div>

      {/* KPIs */}
      <div className="px-5 mt-5 grid grid-cols-3 gap-2">
        {[
          { label: "Almoços/mês", value: "31", trend: "+12%", up: true },
          { label: "Total 2026", value: "343", trend: "+8%", up: true },
          { label: "Evasão", value: "9%", trend: "-3%", up: false },
        ].map((k, i) => (
          <div
            key={k.label}
            style={{ animationDelay: `${i * 60}ms` }}
            className="bg-card rounded-xl shadow-card p-3 animate-slide-up"
          >
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">
              {k.label}
            </p>
            <p className="text-xl font-black mt-1">{k.value}</p>
            <span
              className={`text-[10px] font-bold flex items-center gap-0.5 ${
                k.up ? "text-success" : "text-destructive"
              }`}
            >
              {k.up ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
              {k.trend}
            </span>
          </div>
        ))}
      </div>

      {/* Gráfico: média mensal */}
      <div className="px-5 mt-5">
        <ChartCard title="Média de almoços por mês">
          <ResponsiveContainer width="100%" height={170}>
            <BarChart data={monthlyAvg}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="mes" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  borderRadius: 12,
                  border: "1px solid hsl(var(--border))",
                  fontSize: 12,
                }}
              />
              <Bar dataKey="almocos" fill="hsl(var(--primary))" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Gráfico: evasão */}
      <div className="px-5 mt-4">
        <ChartCard title="Evasão por dia da semana">
          <ResponsiveContainer width="100%" height={170}>
            <LineChart data={evasao}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
              <XAxis dataKey="dia" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
              <Tooltip
                contentStyle={{
                  borderRadius: 12,
                  border: "1px solid hsl(var(--border))",
                  fontSize: 12,
                }}
              />
              <Line
                type="monotone"
                dataKey="evasao"
                stroke="hsl(var(--accent))"
                strokeWidth={3}
                dot={{ r: 4, fill: "hsl(var(--accent))" }}
              />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Frequência por curso */}
      <div className="px-5 mt-4 mb-6">
        <ChartCard title="Frequência por curso (%)">
          <div className="space-y-2.5 mt-1">
            {freqCurso.map((c) => (
              <div key={c.curso}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="font-semibold">{c.curso}</span>
                  <span className="text-muted-foreground">{c.freq}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-primary rounded-full transition-all"
                    style={{ width: `${c.freq}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </ChartCard>
      </div>
    </MobileShell>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-card rounded-2xl shadow-card p-4 animate-float-in">
      <h3 className="font-bold text-sm mb-2">{title}</h3>
      {children}
    </div>
  );
}
