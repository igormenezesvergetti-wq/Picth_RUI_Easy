import { useState } from "react";
import MobileShell from "@/components/MobileShell";
import HeroHeader from "@/components/HeroHeader";
import { Send, ThumbsUp, ThumbsDown, MessageSquare } from "lucide-react";
import { toast } from "sonner";

const tags = [
  { id: "elogio", label: "Elogio", Icon: ThumbsUp, color: "bg-success/15 text-success" },
  { id: "sugestao", label: "Sugestão", Icon: MessageSquare, color: "bg-primary-soft text-primary" },
  { id: "critica", label: "Crítica", Icon: ThumbsDown, color: "bg-destructive/15 text-destructive" },
];

export default function Fale() {
  const [tag, setTag] = useState("sugestao");
  const [text, setText] = useState("");

  const send = () => {
    if (!text.trim()) return;
    toast.success("Mensagem enviada para o RU!");
    setText("");
  };

  return (
    <MobileShell>
      <HeroHeader title="Fale com o RU" subtitle="Sua opinião conta" showBack compact />

      <div className="px-5 -mt-6">
        <div className="bg-card rounded-2xl shadow-card p-5 animate-float-in">
          <p className="text-sm font-semibold mb-2">Tipo de mensagem</p>
          <div className="grid grid-cols-3 gap-2">
            {tags.map((t) => (
              <button
                key={t.id}
                onClick={() => setTag(t.id)}
                className={`flex flex-col items-center gap-1 py-3 rounded-xl border-2 transition-smooth ${
                  tag === t.id ? "border-primary" : "border-border"
                }`}
              >
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${t.color}`}>
                  <t.Icon size={18} />
                </div>
                <span className="text-xs font-semibold">{t.label}</span>
              </button>
            ))}
          </div>

          <p className="text-sm font-semibold mt-5 mb-2">Sua mensagem</p>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            rows={5}
            placeholder="Conte como foi sua experiência hoje no RU..."
            className="w-full border-2 border-border rounded-xl p-3 focus:border-primary outline-none resize-none transition-smooth"
          />

          <button
            onClick={send}
            className="mt-3 w-full py-3.5 rounded-xl font-bold bg-gradient-primary text-primary-foreground flex items-center justify-center gap-2 shadow-elevated"
          >
            <Send size={18} /> Enviar
          </button>
        </div>
      </div>
    </MobileShell>
  );
}
